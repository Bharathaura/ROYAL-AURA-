
export function Home() {
  return (
    <div className="text-center text-3xl font-bold text-gold p-8">
      Welcome to Royal Aura - Your Dropshipping Kingdom
    </div>
  );
}
